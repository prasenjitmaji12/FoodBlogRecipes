import * as contentful from "contentful";

export const client = contentful.createClient({
  space: "a1y1y1rrcmj9",
  accessToken: "qpMomCMbxYdbK_HYfa8ZtFqlCHRBVmTgJ4eb1tc7Mhg"
});
